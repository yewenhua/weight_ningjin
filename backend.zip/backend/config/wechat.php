<?php

/*
 * wxpay
 */

return [
    'appid' => "wx614bc84ce6a07f87",
    'appsecret' => "686e8fc06944200532683bb1f7adb9d4",
    'token' => '08525b857f40f7b87ee4a0206e8e318f',
    'platform' => 'test'
];