<?php


return [
    'merchant_admin' => 'http://compute.koudaiwanle.com',
    'front_admin' => 'https://zj.koudaiwanle.com/frontapi',
    'location_key' => '2XKBZ-UFYH6-JE5SC-MY3VY-AWUBT-ODFAB',
    'api_url' => 'http://j43606b680.eicp.vip',
];
