<?php
/**
 * 微信小程序
 */

return [
    'appid' => "wxa434eb05e32c4cdf",
    'appsecret' => "a38026f3c0df34bf6f542037fdb7dafc",
    'templateid' => "",
    'platform' => 'minikdwl'
];