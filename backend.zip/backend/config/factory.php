<?php
/**
 * 电厂名称列表，英文全拼 + 期数
 */

return [
    'yongqiang2',
    'yuhuan1'
];
