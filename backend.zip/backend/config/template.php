<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/10/10
 * Time: 14:28
 */

return [
    'tag_alarm' => "8ARrhjG6AOtV-0UAWQGq1pmI7w9OfW6q4YLuDatwblk",
    'date_data' => "OG80M9UOgoLzlJ-215FcOtHwLONXxNX3A2eEg6Iy9WE",
    'month_data' => "ZsKXCYs6N8CM3Zcsqc7SwXYquGBFEP9lkACbgJ1hTK0"
];
