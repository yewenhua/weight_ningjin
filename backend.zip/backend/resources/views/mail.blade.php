<!DOCTYPE html>
     <html>
     <head>
         <meta charset="UTF-8">
         <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <meta http-equiv="X-UA-Compatible" content="ie=edge">
         <title>富文本邮件</title>
         <style>
             div {
                 font-size: 18px;
                 font-weight: bold;
                 color:green;
             }
         </style>
     </head>
     <body>
         <h1>{{ $name }}</h1>

         <div>
             自如初个人博客
         </div>
     </body>
     </html>
